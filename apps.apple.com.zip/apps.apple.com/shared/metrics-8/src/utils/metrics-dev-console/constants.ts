/**
 * Event type constants for metrics development console
 */
export const eventType = {
    RECORD: 'record',
    FLUSH: 'flush',
} as const;
