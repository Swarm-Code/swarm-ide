<script lang="ts" context="module">
    export const id = 'hero-carousel-shelf-background-portal';
</script>

<div {id} />

<style>
    #hero-carousel-shelf-background-portal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow-x: hidden;
        z-index: -1;
    }
</style>
